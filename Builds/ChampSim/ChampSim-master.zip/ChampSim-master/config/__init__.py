'''
ChampSim uses an initial configuration step, written in Python, to parse the JSON configuration file into C++ files for
building.
The configuration mechanism can be used programmatically, as a Python module.
'''
