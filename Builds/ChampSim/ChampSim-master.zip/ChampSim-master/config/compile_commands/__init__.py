"""Functions and scripts for generating compile_commands.json files for LSPs."""
