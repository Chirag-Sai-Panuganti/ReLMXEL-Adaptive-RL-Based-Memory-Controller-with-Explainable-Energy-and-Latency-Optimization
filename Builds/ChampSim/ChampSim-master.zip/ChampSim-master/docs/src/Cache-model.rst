.. _Cache_model:

=====================================
Cache Model
=====================================

.. doxygenclass:: CACHE
   :members:

----------------------------------
Builder
----------------------------------

.. doxygenclass:: champsim::cache_builder
   :members:

