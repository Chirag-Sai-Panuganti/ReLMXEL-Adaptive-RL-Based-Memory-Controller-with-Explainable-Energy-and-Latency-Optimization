.. _Core_model:

=====================================
Core Model
=====================================

.. doxygenclass:: O3_CPU
   :members:

----------------------------------
Builder
----------------------------------

.. doxygenclass:: champsim::core_builder
   :members:

