.. _Publications:

================================
Publications
================================

ChampSim is primarily exhibited in

.. bibliography::
   :list: bullet
   :filter: False

   gober2022championship

Other publications that use ChampSim for their results are listed below:

.. bibliography::
   :list: bullet
   :style: year_author_title
   :filter: key not in {'gober2022championship'}
