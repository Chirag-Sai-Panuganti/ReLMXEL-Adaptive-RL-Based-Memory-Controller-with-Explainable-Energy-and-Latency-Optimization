#define CATCH_CONFIG_MAIN
#include <catch.hpp>

#include "champsim.h"
const std::size_t NUM_CPUS = 1;

const unsigned BLOCK_SIZE = 64;
const unsigned PAGE_SIZE = 4096;
